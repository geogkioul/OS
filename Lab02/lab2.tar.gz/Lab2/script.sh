#!/bin/bash
current_time=$(date +%s)
echo "Current time: $current_time"
let "current_time_doubled = current_time * 2"
echo "Current time * 2: $current_time_doubled"

for i in {1..20}; do
echo "$i"
done
